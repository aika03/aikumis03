package kz.narxoz.springsecurity.narxozsecurity.narxozSecurity;


import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NarxozSecurityApplicationTests {
	NarxozSecurityApplicationTests() {
	}

	@Test
	void contextLoads() {
	}
}
